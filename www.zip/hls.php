<?php
// Coded by Khai Phan

header("Content-Type: text/plain");

$accounts = array(
    'admin' => '123456',
);

$username = $_GET['user'] ?? '';
$password = $_GET['pass'] ?? '';
if ($username == '' || $password == '' || !array_key_exists($username, $accounts) || $password != $accounts[$username]) {
    http_response_code(403);
    exit;
}

$file = $_GET['file'] ?? '';
$dir = '/tmp/hls';
$filedir = $dir . dirname($file);
$filename = basename($file);
$filepath = $dir . $file;

if ($filename == 'playlist.m3u8' && is_dir($filedir)) {
    $playlist = "#EXTM3U
#EXT-X-VERSION:3\n";
    $playlist .= "#EXT-X-STREAM-INF:BANDWIDTH=800000,RESOLUTION=640x360\n";
    $playlist .= "360p.m3u8\n";
    $playlist .= "#EXT-X-STREAM-INF:BANDWIDTH=1400000,RESOLUTION=842x480\n";
    $playlist .= "480p.m3u8\n";
    $playlist .= "#EXT-X-STREAM-INF:BANDWIDTH=2800000,RESOLUTION=1280x720\n";
    $playlist .= "720p.m3u8\n";
    $playlist .= "#EXT-X-STREAM-INF:BANDWIDTH=5000000,RESOLUTION=1920x1080\n";
    $playlist .= "1080p.m3u8\n";
    file_put_contents($filepath, $playlist);
}

if (!is_readable($filepath)) {
    http_response_code(404);
    exit;
}

switch ($ext = pathinfo($filepath, PATHINFO_EXTENSION)) {
    case 'm3u8':
        $mime_type = 'application/vnd.apple.mpegurl';
        break;
    case 'ts':
        $mime_type = 'video/mp2t';
        break;
    default:
        $mime_type = 'application/octet-stream';
}

header("Cache-Control: no-cache");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Expose-Headers: Content-Length,Content-Range");
header("Access-Control-Allow-Headers: Range");
header("Content-Type: $mime_type");

if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    header("Access-Control-Max-Age: 1728000");
    header("Content-Type: text/plain; charset=UTF-8");
    header("Content-Length: 0");
    http_response_code(204);
    exit;
}

if ($ext == 'm3u8') {
    $hls_base_url = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://" . $_SERVER['HTTP_HOST'] . dirname($_SERVER['REQUEST_URI']);
    $query_string = parse_url($_SERVER['REQUEST_URI'], PHP_URL_QUERY);
    $query_string = $query_string != ""  ? "?$query_string" : "\n";
    $content = file_get_contents($filepath);
    $content = preg_replace('/(.*\.m3u8|.*\.ts)/', "$hls_base_url/$1$query_string", $content);
    echo $content;
} else {
    readfile($filepath);
}
