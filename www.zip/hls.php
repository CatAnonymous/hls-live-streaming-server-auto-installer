<?php
// Coded by Khai Phan

header("Content-Type: text/plain; charset=UTF-8");

$accounts = array(
  'admin' => '123456',
);

$username = $_GET['user'] ?? '';
$password = $_GET['pass'] ?? '';

if ($username == '' || $password == '' || !array_key_exists($username, $accounts) || $password != $accounts[$username]) {
  http_response_code(403);
  exit;
}

$file = $_GET['file'] ?? '';
$dir = '/tmp/hls';
$filepath = $dir . $file;

if ($uri == '' || !is_file($filepath)) {
  http_response_code(404);
  exit;
} else {
  $ext = pathinfo($filepath, PATHINFO_EXTENSION);
  if ($ext == 'm3u8') {
    $mime_type = 'application/vnd.apple.mpegurl';
  } elseif ($ext == 'ts') {
    $mime_type = 'video/mp2t';
  } else {
    $mime_type = 'application/octet-stream';
  }
  
  header("Cache-Control: no-cache");
  header("Access-Control-Allow-Origin: *");
  header("Access-Control-Expose-Headers: Content-Length,Content-Range");
  header("Access-Control-Allow-Headers: Range");
  header("Content-Type: $mime_type");

  if ($_SERVER['REQUEST_METHOD'] = 'OPTIONS') {
    header("Access-Control-Max-Age: 1728000");
    header("Content-Type: text/plain; charset=UTF-8");
    header("Content-Length: 0");
    http_response_code(204);
    exit;
  }

  if ($ext == 'm3u8') {
    $segment_prefix = '';
    $content = file_get_contents($filepath);
    $content = preg_replace('/(.*\.ts)/', "$segment_prefix$1?user=$username&pass=$password", $content);
    echo $content;
  } else {
    readfile($filepath);
  }
}
