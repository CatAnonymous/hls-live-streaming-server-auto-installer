<?php
http_response_code(200);
die();